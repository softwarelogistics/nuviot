#ifndef ADC_ESP32_H
#define ADC_ESP32_H


#include <Wire.h>
#include <Arduino>
#include "AbstractSensor.h"

class ADC_Esp32 : public AbstractSensor
{

};

#endif

