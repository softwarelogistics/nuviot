#include "BluetoothServer.h"

void BluetoothServer::Setup()
{
}

void BluetoothServer::Loop()
{
}

void BluetoothServer::begin(String name){
 //   btSerial.begin(name);
}
void BluetoothServer::print(String str)
{
}
void BluetoothServer::println(String str)
{
}
void BluetoothServer::println()
{
}
int BluetoothServer::available()
{
    return 0;
}
void BluetoothServer::flush()
{
}
unsigned char BluetoothServer::read()
{
    return 0xff;
}
